1) TO COMPILE AND RUN "gpp_lexer.l" DO THE FOLLOWING:

	$ flex gpp_lexer.l
	$ gcc -o output lex.yy.c
	$ ./output (OR) ./output example.g++
	$ rm output

	In case of you didn't enter a filename as argument, program will continue until you terminate it.
	This is designed to be "REPL"

2) TO COMPILE AND RUN "gpp_lexer.lisp" DO THE FOLLOWING:
	$ clisp gpp_lexer.lisp (OR) clisp gpp_lexer.lisp example.g++
